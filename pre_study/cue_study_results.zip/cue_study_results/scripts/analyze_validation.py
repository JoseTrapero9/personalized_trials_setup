"""
Validation-cue analysis
=======================
Reads every <subject>_<timestamp>.csv from the validation_cues_answers folder
(or the .zip directly), cleans it, prints a report and saves figures + CSVs.

Each CSV is one block: feedback_modality x location_mapping, with trials of
  location, stimulus_type (positive_1..3 / negative_1..3), chosen_correctly, reaction_time

Exclusions (configurable below):
  * practice files                      (file name contains "practice")
  * non-random blocks                   (fewer than MIN_STIM_TYPES different cues
                                         -> drops s03's six fixed-pair blocks)
  * first trial of every block          (RT warm-up, often 5-11 s)  - RT only
  * RTs outside [RT_MIN, RT_MAX] s      (anticipations / lapses)     - RT only
  * RT analyses use correct trials only
Incomplete subjects (missing blocks) are kept; paired tests use whoever has both levels.

Usage:
    python analyze_validation.py validation_cues_answers/
    python analyze_validation.py validation_cues_answers.zip -o validation_results
    python analyze_validation.py validation_cues_answers/ --prestudy path/to/pre_study_jsons

Requires: pandas, numpy, matplotlib  (scipy optional, for the tests)
"""

import argparse
import glob
import io
import json
import os
import re
import zipfile

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

try:
    from scipy import stats
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False

# ----------------------------- settings ------------------------------------ #
MIN_STIM_TYPES = 6        # a "random" block contains all 6 cue types
DROP_FIRST_TRIAL = True   # first trial of each block excluded from RT
RT_MIN, RT_MAX = 0.15, 5.0  # seconds, RT analyses only

CUES = ["positive_1", "positive_2", "positive_3", "negative_1", "negative_2", "negative_3"]
MODALITIES = ["Haptics Only", "Haptics + Audio"]
MAPPINGS = ["correct_back", "correct_front"]

COL = {"Haptics Only": "#2a78b5", "Haptics + Audio": "#d1622b",
       "correct_back": "#5b8c3a", "correct_front": "#8a5bb0",
       "positive": "#2a78b5", "negative": "#d1622b"}

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 200, "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
})


# ----------------------------- loading ------------------------------------- #
def iter_csvs(src):
    """Yield (filename, DataFrame) from a folder or a .zip."""
    if src.lower().endswith(".zip"):
        with zipfile.ZipFile(src) as z:
            for name in sorted(z.namelist()):
                if name.lower().endswith(".csv") and not name.startswith("__MACOSX"):
                    yield os.path.basename(name), pd.read_csv(io.BytesIO(z.read(name)))
    else:
        files = sorted(glob.glob(os.path.join(src, "**", "*.csv"), recursive=True))
        for f in files:
            yield os.path.basename(f), pd.read_csv(f)


def load(src):
    kept, log = [], []
    for fname, d in iter_csvs(src):
        m = re.match(r"(s\d+)", fname)
        sid = m.group(1) if m else fname
        ts = re.search(r"(\d{8}_\d{6})", fname)
        ts = ts.group(1) if ts else ""
        n_types = d["stimulus_type"].nunique()

        if "practice" in fname.lower():
            log.append((fname, sid, "excluded: practice"))
            continue
        if n_types < MIN_STIM_TYPES:
            log.append((fname, sid, f"excluded: not random ({n_types} cue types: "
                                    f"{', '.join(sorted(d['stimulus_type'].unique()))})"))
            continue

        d = d.copy()
        d["subject"] = sid            # file name wins over 'subject_name' (s03/s05 say 'Player 1')
        d["file"] = fname
        d["timestamp"] = ts
        d["trial"] = np.arange(1, len(d) + 1)
        d["correct"] = d["chosen_correctly"].str.strip().str.lower().eq("yes").astype(int)
        d["valence"] = d["stimulus_type"].str.split("_").str[0]
        log.append((fname, sid, f"kept ({len(d)} trials)"))
        kept.append(d)

    if not kept:
        raise SystemExit("No usable blocks found.")
    df = pd.concat(kept, ignore_index=True)

    # block order within subject (1st, 2nd, ... block run)
    order = (df[["subject", "timestamp"]].drop_duplicates()
             .sort_values(["subject", "timestamp"]))
    order["block_order"] = order.groupby("subject").cumcount() + 1
    df = df.merge(order, on=["subject", "timestamp"])

    # RT-valid flag
    rt_ok = df["reaction_time"].between(RT_MIN, RT_MAX) & (df["correct"] == 1)
    if DROP_FIRST_TRIAL:
        rt_ok &= df["trial"] > 1
    df["rt_valid"] = rt_ok
    return df, pd.DataFrame(log, columns=["file", "subject", "status"])


# ----------------------------- helpers ------------------------------------- #
def subj_cell(df, by, measure):
    """Per-subject value of a measure (accuracy = mean, rt = median of valid trials)."""
    if measure == "acc":
        return df.groupby(["subject"] + by)["correct"].mean().rename("acc")
    return df[df["rt_valid"]].groupby(["subject"] + by)["reaction_time"].median().rename("rt")


def paired_test(wide, a, b, label):
    w = wide[[a, b]].dropna()
    if not HAVE_SCIPY or len(w) < 3:
        return f"{label}: n={len(w)} (no test)"
    diff = w[b] - w[a]
    if np.allclose(diff, 0):
        return f"{label}: n={len(w)}, no differences"
    res = stats.wilcoxon(w[a], w[b])
    return (f"{label}: n={len(w)}, {a} {w[a].mean():.3f} vs {b} {w[b].mean():.3f}, "
            f"Wilcoxon W={res.statistic:.1f}, p={res.pvalue:.3f}")


def paired_plot(ax, wide, levels, ylabel, title, fmt="{:.2f}", pct=False):
    """Only subjects with data in every level are drawn, so the mean is truly paired."""
    wide = wide[levels].dropna()
    for _, row in wide.iterrows():
        ax.plot(range(len(levels)), row.values, color="grey", alpha=0.5, lw=1, marker="o", ms=3)
    means = wide.mean()
    ax.plot(range(len(levels)), means.values, color="black", lw=2.5, marker="D", ms=7, zorder=5)
    for i, v in enumerate(means.values):
        left = i == 0
        ax.text(i + (-0.08 if left else 0.08), v, (f"{v*100:.1f}%" if pct else fmt.format(v)),
                va="center", ha="right" if left else "left", fontsize=9, fontweight="bold")
    ax.set_xticks(range(len(levels)), [l.replace("correct_", "") for l in levels])
    ax.set_xlim(-0.45, len(levels) - 0.55)
    ax.set_ylabel(ylabel)
    ax.set_title(f"{title} (n={len(wide)})")


# ----------------------------- figures ------------------------------------- #
def fig_overview_heatmaps(df, out):
    df = df.assign(cond=df["feedback_modality"].str.replace("Haptics + Audio", "H+A")
                   .str.replace("Haptics Only", "H") + " / " + df["location_mapping"].str.replace("correct_", ""))
    conds = ["H / back", "H / front", "H+A / back", "H+A / front"]
    acc = df.groupby(["subject", "cond"])["correct"].mean().unstack().reindex(columns=conds)
    rt = df[df["rt_valid"]].groupby(["subject", "cond"])["reaction_time"].median().unstack().reindex(columns=conds)

    fig, axes = plt.subplots(1, 2, figsize=(12, 0.45 * len(acc) + 1.8))
    for ax, data, cmap, title, f, lims in [
        (axes[0], acc * 100, "RdYlGn", "Accuracy (%)", "{:.0f}", (50, 100)),
        (axes[1], rt, "viridis_r", "Median RT, correct trials (s)", "{:.2f}", (None, None)),
    ]:
        im = ax.imshow(data.values, cmap=cmap, aspect="auto", vmin=lims[0], vmax=lims[1])
        for r in range(data.shape[0]):
            for c in range(data.shape[1]):
                v = data.iat[r, c]
                ax.text(c, r, "missing" if pd.isna(v) else f.format(v),
                        ha="center", va="center", fontsize=8.5,
                        color="grey" if pd.isna(v) else "black")
        ax.set_xticks(range(len(conds)), conds)
        ax.set_yticks(range(len(data)), data.index)
        ax.set_title(title)
        for s in ax.spines.values():
            s.set_visible(False)
        fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    fig.suptitle("Per subject and condition (H = Haptics only, H+A = Haptics + Audio)")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "01_subject_condition_heatmaps.png"))
    plt.close(fig)


def fig_conditions(df, out):
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    for col, (factor, levels) in enumerate([("feedback_modality", MODALITIES),
                                            ("location_mapping", MAPPINGS)]):
        acc = subj_cell(df, [factor], "acc").unstack()
        rt = subj_cell(df, [factor], "rt").unstack()
        nice = "Modality" if col == 0 else "Spatial mapping"
        paired_plot(axes[0, col], acc, levels, "Accuracy", f"{nice}: accuracy", pct=True)
        paired_plot(axes[1, col], rt, levels, "Median RT (s)", f"{nice}: reaction time")
        axes[0, col].yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v*100:.0f}%"))
    fig.suptitle("Grey = individual subjects, black = mean across subjects")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "02_modality_and_mapping.png"))
    plt.close(fig)


def fig_cues(df, out):
    acc = subj_cell(df, ["stimulus_type"], "acc").unstack().reindex(columns=CUES)
    rt = subj_cell(df, ["stimulus_type"], "rt").unstack().reindex(columns=CUES)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    rng = np.random.default_rng(1)
    for ax, data, ylab, pct in [(axes[0], acc, "Accuracy", True), (axes[1], rt, "Median RT (s)", False)]:
        means = data.mean()
        sem = data.sem()
        colors = [COL[c.split("_")[0]] for c in CUES]
        ax.bar(range(6), means, yerr=sem, color=colors, alpha=0.75, capsize=4)
        for i, c in enumerate(CUES):
            y = data[c].dropna()
            ax.scatter(i + rng.uniform(-0.15, 0.15, len(y)), y, s=14, color="black", alpha=0.6, zorder=3)
        ax.set_xticks(range(6), CUES, rotation=20)
        ax.set_ylabel(ylab)
        ax.axvline(2.5, color="grey", ls=":", lw=0.8)
        lo = max(0, np.nanmin(data.values) - 0.05) if pct else 0
        if pct:
            ax.set_ylim(lo, 1.02)
            ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v*100:.0f}%"))
        top = ax.get_ylim()[1]
        for i, c in enumerate(CUES):  # mean label inside the bar, near its base
            ax.text(i, lo + 0.04 * (top - lo), f"{means[c]*100:.1f}%" if pct else f"{means[c]:.2f}",
                    ha="center", fontsize=9, color="white", fontweight="bold")
    axes[0].set_title("Recognition accuracy per cue (bar = mean ± SEM, dots = subjects)")
    axes[1].set_title("Reaction time per cue")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "03_per_cue.png"))
    plt.close(fig)


def fig_valence_location(df, out):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    # valence x mapping, RT
    rt = subj_cell(df, ["location_mapping", "valence"], "rt").reset_index()
    acc = subj_cell(df, ["location_mapping", "valence"], "acc").reset_index()
    for ax, data, col, ylab in [(axes[0], acc, "acc", "Accuracy"), (axes[1], rt, "rt", "Median RT (s)")]:
        for v in ["positive", "negative"]:
            m = data[data["valence"] == v].groupby("location_mapping")[col].agg(["mean", "sem"]).reindex(MAPPINGS)
            ax.errorbar(np.arange(2) + (-0.05 if v == "positive" else 0.05), m["mean"], yerr=m["sem"],
                        marker="o", capsize=4, lw=2, color=COL[v], label=f"{v} cues")
        ax.set_xticks([0, 1], ["mapping: back", "mapping: front"])
        ax.set_xlim(-0.4, 1.4)
        ax.set_ylabel(ylab)
        ax.legend(frameon=False)
    axes[0].yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v*100:.1f}%"))
    axes[0].set_title("Accuracy: valence × mapping (mean ± SEM)")
    axes[1].set_title("RT: valence × mapping (mean ± SEM)")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "04_valence_x_mapping.png"))
    plt.close(fig)


def fig_time_effects(df, out):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    # RT distribution
    ax = axes[0]
    valid = df[df["rt_valid"]]
    for mod in MODALITIES:
        ax.hist(valid.loc[valid["feedback_modality"] == mod, "reaction_time"], bins=40,
                range=(RT_MIN, 2.5), alpha=0.55, color=COL[mod], label=mod, density=True)
    ax.set_xlabel("RT (s)")
    ax.set_ylabel("Density")
    ax.set_title("RT distribution (valid correct trials)")
    ax.legend(frameon=False)

    # within-block learning curve (bins of 10 trials)
    ax = axes[1]
    d = df[df["rt_valid"]].copy()
    d["bin"] = ((d["trial"] - 1) // 10) * 10 + 5
    curve = d.groupby(["subject", "bin"])["reaction_time"].median().groupby("bin").agg(["mean", "sem", "count"])
    curve = curve[curve["count"] >= 3]
    ax.errorbar(curve.index, curve["mean"], yerr=curve["sem"], marker="o", capsize=3, color="black")
    ax.set_xlabel("Trial within block (bins of 10)")
    ax.set_ylabel("Median RT (s)")
    ax.set_title("Within-block RT over trials")

    # block order (practice / fatigue)
    ax = axes[2]
    acc = df.groupby(["subject", "block_order"])["correct"].mean().unstack()
    rt = df[df["rt_valid"]].groupby(["subject", "block_order"])["reaction_time"].median().unstack()
    x = rt.columns
    ax.errorbar(x, rt.mean(), yerr=rt.sem(), marker="o", capsize=3, color="black", label="RT")
    ax.set_xlabel("Block order (1 = first block run)")
    ax.set_ylabel("Median RT (s)")
    ax2 = ax.twinx()
    ax2.plot(acc.columns, acc.mean() * 100, marker="s", color="#5b8c3a", label="Accuracy")
    ax2.set_ylabel("Accuracy (%)", color="#5b8c3a")
    ax2.spines["right"].set_visible(True)
    ax.set_xticks(list(x))
    ax.set_title("Order effects across blocks")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "05_rt_distribution_and_order.png"))
    plt.close(fig)


def fig_prestudy_link(df, prestudy_dir, out):
    """Optional: relate pre-study usefulness scores to validation performance per cue."""
    rows = []
    for f in sorted(glob.glob(os.path.join(prestudy_dir, "pre_study_*.json"))):
        m = re.search(r"_(s\d+)_", os.path.basename(f))
        if not m:
            continue
        d = json.load(open(f, encoding="utf-8"))
        for key in ("assessment_correct_cues", "assessment_incorrect_cues"):
            for cue, v in d[key]["cues"].items():
                rows.append({"subject": m.group(1), "stimulus_type": cue, "usefulness": v["usefulness_score"]})
    if not rows:
        print("[prestudy] no pre_study_*.json found - skipping link figure")
        return None
    pre = pd.DataFrame(rows)
    perf = (subj_cell(df, ["stimulus_type"], "acc").to_frame()
            .join(subj_cell(df, ["stimulus_type"], "rt")).reset_index())
    m = perf.merge(pre, on=["subject", "stimulus_type"])

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    lines = []
    for ax, col, ylab in [(axes[0], "acc", "Accuracy"), (axes[1], "rt", "Median RT (s)")]:
        for v in ["positive", "negative"]:
            s = m[m["stimulus_type"].str.startswith(v)]
            ax.scatter(s["usefulness"], s[col], color=COL[v], alpha=0.7, label=f"{v} cues")
        ax.set_xlabel("Pre-study usefulness score (0–10)")
        ax.set_ylabel(ylab)
        ax.legend(frameon=False)
        if HAVE_SCIPY:
            r = m[["usefulness", col]].dropna()
            rho, p = stats.spearmanr(r["usefulness"], r[col])
            ax.set_title(f"Usefulness vs {ylab.split()[0].lower()}  (Spearman ρ={rho:.2f}, p={p:.3f})")
            lines.append(f"Usefulness vs {col}: Spearman rho={rho:.2f}, p={p:.3f} "
                         f"(n={len(r)} subject×cue pairs, not independent - exploratory)")
    if not HAVE_SCIPY:
        axes[0].set_title("Usefulness vs accuracy")
        axes[1].set_title("Usefulness vs RT")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "06_prestudy_usefulness_vs_performance.png"))
    plt.close(fig)
    return lines


# ----------------------------- main ---------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src", nargs="?", default="validation_cues_answers",
                    help="folder with the CSVs, or the .zip")
    ap.add_argument("-o", "--out", default="validation_results")
    ap.add_argument("--prestudy", help="folder with pre_study_*.json (optional link analysis)")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    pd.set_option("display.width", 160)

    df, log = load(args.src)

    print("\n=== Files ===")
    for _, r in log.iterrows():
        print(f"  {r.file:40s} {r.status}")

    # completeness
    blocks = (df.groupby(["subject", "feedback_modality", "location_mapping"])["file"].nunique()
              .unstack(["feedback_modality", "location_mapping"]).fillna(0).astype(int))
    print("\n=== Blocks per subject (modality x mapping) ===")
    print(blocks.to_string())
    incomplete = blocks.index[(blocks == 0).any(axis=1)].tolist()
    if incomplete:
        print(f"Incomplete subjects (kept): {', '.join(incomplete)}")

    n_trials = len(df)
    n_rt = int(df["rt_valid"].sum())
    print(f"\nTrials analysed: {n_trials}  |  valid for RT: {n_rt} "
          f"({n_trials - n_rt} removed: errors, first trial per block, RT outside {RT_MIN}-{RT_MAX} s)")

    # overall
    acc_s = df.groupby("subject")["correct"].mean()
    rt_s = df[df["rt_valid"]].groupby("subject")["reaction_time"].median()
    overall = pd.DataFrame({"accuracy_%": (acc_s * 100).round(1), "median_rt_s": rt_s.round(3),
                            "trials": df.groupby("subject").size()})
    print("\n=== Per subject ===")
    print(overall.to_string())
    print(f"Group: accuracy {acc_s.mean()*100:.1f}% ± {acc_s.std()*100:.1f}, "
          f"median RT {rt_s.mean():.3f} ± {rt_s.std():.3f} s (mean ± SD across subjects)")

    # per cue
    cue_acc = subj_cell(df, ["stimulus_type"], "acc").unstack().reindex(columns=CUES)
    cue_rt = subj_cell(df, ["stimulus_type"], "rt").unstack().reindex(columns=CUES)
    cue_tab = pd.DataFrame({"accuracy_%": (cue_acc.mean() * 100).round(1),
                            "acc_sd": (cue_acc.std() * 100).round(1),
                            "median_rt_s": cue_rt.mean().round(3),
                            "rt_sd": cue_rt.std().round(3),
                            "trials": df.groupby("stimulus_type").size().reindex(CUES)})
    print("\n=== Per cue (mean across subjects) ===")
    print(cue_tab.to_string())

    # condition tables
    cond = (df.groupby(["feedback_modality", "location_mapping"])
            .apply(lambda g: pd.Series({"accuracy_%": g["correct"].mean() * 100,
                                        "median_rt_s": g.loc[g["rt_valid"], "reaction_time"].median(),
                                        "trials": len(g)}), include_groups=False).round(3))
    print("\n=== Pooled by condition ===")
    print(cond.to_string())

    # tests
    print("\n=== Tests (subjects as unit; exploratory) ===")
    tests = []
    for factor, (a, b) in [("feedback_modality", MODALITIES), ("location_mapping", MAPPINGS)]:
        for meas in ["acc", "rt"]:
            w = subj_cell(df, [factor], meas).unstack()
            tests.append(paired_test(w, a, b, f"{factor} / {meas}"))
    for meas in ["acc", "rt"]:
        w = subj_cell(df, ["valence"], meas).unstack()
        tests.append(paired_test(w, "positive", "negative", f"valence / {meas}"))
    if HAVE_SCIPY:
        for meas, w in [("acc", cue_acc), ("rt", cue_rt)]:
            w = w.dropna()
            if len(w) >= 3:
                chi, p = stats.friedmanchisquare(*[w[c] for c in CUES])
                tests.append(f"6 cues / {meas}: Friedman chi2(5)={chi:.2f}, p={p:.3f}, n={len(w)}")
    for t in tests:
        print("  " + t)

    if args.prestudy:
        print("\n=== Link with pre-study ===")
        for line in fig_prestudy_link(df, args.prestudy, args.out) or []:
            print("  " + line)
            tests.append(line)

    # save
    df.to_csv(os.path.join(args.out, "trials_clean.csv"), index=False)
    log.to_csv(os.path.join(args.out, "file_log.csv"), index=False)
    overall.to_csv(os.path.join(args.out, "per_subject.csv"))
    cue_tab.to_csv(os.path.join(args.out, "per_cue.csv"))
    cond.to_csv(os.path.join(args.out, "per_condition.csv"))
    with open(os.path.join(args.out, "tests.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(tests))

    fig_overview_heatmaps(df, args.out)
    fig_conditions(df, args.out)
    fig_cues(df, args.out)
    fig_valence_location(df, args.out)
    fig_time_effects(df, args.out)

    print(f"\nFigures and CSVs saved to: {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
