"""
Pre-study cue feedback analysis
================================
Reads every pre_study_*.json in a folder, prints summary statistics and
saves figures + tidy CSVs.

Usage:
    python analyze_pre_study.py                 # JSONs in current folder
    python analyze_pre_study.py path/to/jsons   # JSONs elsewhere
    python analyze_pre_study.py path -o results # custom output folder

Requires: pandas, numpy, matplotlib  (scipy optional, for the tests)
"""

import argparse
import glob
import json
import os
import re

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle

try:
    from scipy import stats
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False

POS_CUES = ["positive_1", "positive_2", "positive_3"]
NEG_CUES = ["negative_1", "negative_2", "negative_3"]
ALL_CUES = POS_CUES + NEG_CUES
BLOCKS = {"correct": "assessment_correct_cues", "incorrect": "assessment_incorrect_cues"}
INTENSITY_ORDER = ["Decrease", "Keep", "Increase"]

COL_POS = "#2a78b5"   # correct-action cues
COL_NEG = "#d1622b"   # incorrect-action cues
COL_MUTED = "#c4c4c4"

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 200, "font.size": 10,
    "axes.spines.top": False, "axes.spines.right": False,
})


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def participant_id(path, data):
    """Take the ID from the file name (s01, s02 ...). The 'participant' field
    is not reliable (s03 was saved as 'Player 1')."""
    m = re.search(r"_(s\d+)_", os.path.basename(path))
    return m.group(1) if m else str(data.get("participant"))


def load(folder):
    files = sorted(glob.glob(os.path.join(folder, "pre_study_*.json")))
    if not files:
        raise SystemExit(f"No pre_study_*.json files found in {os.path.abspath(folder)}")

    cue_rows, part_rows = [], []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            d = json.load(fh)
        pid = participant_id(f, d)
        if d.get("participant") != pid:
            print(f"[note] {os.path.basename(f)}: participant field is "
                  f"'{d.get('participant')}', using '{pid}' from the file name")

        setup = d["spatial_mapping_setup"]
        part = {
            "participant": pid,
            "timestamp": d.get("timestamp"),
            "tested_mapping": setup["current_test_mapping"],
            "preferred_mapping": setup["preferred_spatial_mapping"],
            "length_pref": setup["guidance_length_preference"],
        }
        for block, key in BLOCKS.items():
            a = d[key]
            part[f"liked_{block}"] = a["most_liked_cue"]
            part[f"perception_{block}"] = a["perception_difference"]
            for cue, v in a["cues"].items():
                cue_rows.append({
                    "participant": pid, "block": block, "cue": cue,
                    "score": v["usefulness_score"],
                    "intensity": v["guidance_intensity"].replace(" intensity", ""),
                    "most_liked": cue == a["most_liked_cue"],
                })
        part_rows.append(part)

    return pd.DataFrame(cue_rows), pd.DataFrame(part_rows)


# --------------------------------------------------------------------------- #
# Statistics
# --------------------------------------------------------------------------- #
def cue_summary(cues):
    g = cues.groupby("cue")
    summ = pd.DataFrame({
        "block": g["block"].first(),
        "n": g["score"].size(),
        "mean": g["score"].mean(),
        "sd": g["score"].std(),
        "median": g["score"].median(),
        "min": g["score"].min(),
        "max": g["score"].max(),
        "times_most_liked": g["most_liked"].sum(),
    })
    inten = pd.crosstab(cues["cue"], cues["intensity"]).reindex(columns=INTENSITY_ORDER, fill_value=0)
    summ = summ.join(inten).reindex(ALL_CUES)
    return summ.round(2)


def liked_vs_top(cues):
    """Does the 'most liked' cue also have the highest usefulness score?"""
    rows = []
    for (pid, block), grp in cues.groupby(["participant", "block"]):
        top = grp["score"].max()
        liked = grp[grp["most_liked"]].iloc[0]
        rows.append({
            "participant": pid, "block": block,
            "liked_cue": liked["cue"], "liked_score": liked["score"],
            "top_score": top,
            "top_cues": ", ".join(grp.loc[grp["score"] == top, "cue"]),
            "consistent": liked["score"] == top,
        })
    return pd.DataFrame(rows)


def run_tests(cues):
    out = []
    wide = cues.pivot(index="participant", columns="cue", values="score")
    if not HAVE_SCIPY:
        out.append("scipy not installed - skipping significance tests.")
        return out

    for name, cols in [("correct", POS_CUES), ("incorrect", NEG_CUES)]:
        chi, p = stats.friedmanchisquare(*[wide[c] for c in cols])
        n, k = len(wide), len(cols)
        w = chi / (n * (k - 1))  # Kendall's W (effect size)
        out.append(f"Friedman, {name} cues: chi2({k-1}) = {chi:.2f}, p = {p:.3f}, Kendall's W = {w:.2f}")

    pos_mean = wide[POS_CUES].mean(axis=1)
    neg_mean = wide[NEG_CUES].mean(axis=1)
    res = stats.wilcoxon(pos_mean, neg_mean)
    out.append(f"Wilcoxon, mean correct-cue vs mean incorrect-cue score per participant: "
               f"W = {res.statistic:.1f}, p = {res.pvalue:.3f}")
    return out


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def cue_color(cue):
    return COL_POS if cue.startswith("positive") else COL_NEG


def fig_usefulness(cues, summ, out):
    """Strip plot: one dot per participant, bar = mean, whisker = SD."""
    fig, ax = plt.subplots(figsize=(8, 4.5))
    rng = np.random.default_rng(0)
    for i, cue in enumerate(ALL_CUES):
        s = cues.loc[cues["cue"] == cue, "score"].to_numpy()
        x = i + rng.uniform(-0.12, 0.12, len(s))
        ax.scatter(x, s, s=40, color=cue_color(cue), alpha=0.7, edgecolor="white", zorder=3)
        m, sd = summ.loc[cue, "mean"], summ.loc[cue, "sd"]
        ax.errorbar(i + 0.28, m, yerr=sd, fmt="D", color="black", ms=6, capsize=4, zorder=4)
        ax.text(i + 0.36, m, f"{m:.1f}", va="center", fontsize=9)
    ax.axvline(2.5, color="grey", lw=0.8, ls=":")
    ax.set_xticks(range(len(ALL_CUES)), ALL_CUES, rotation=20)
    ax.set_ylim(-0.5, 11.6)
    ax.set_ylabel("Usefulness score (0–10)")
    ax.set_title("Usefulness per cue (dots = participants, ◆ = mean ± SD)")
    ax.text(1, 11.3, "Correct-action cues", ha="center", color=COL_POS)
    ax.text(4, 11.3, "Incorrect-action cues", ha="center", color=COL_NEG)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "01_usefulness_per_cue.png"))
    plt.close(fig)


def fig_heatmap(cues, out):
    """Participant x cue scores, most-liked cue outlined."""
    wide = cues.pivot(index="participant", columns="cue", values="score")[ALL_CUES]
    liked = cues.pivot(index="participant", columns="cue", values="most_liked")[ALL_CUES]

    fig, ax = plt.subplots(figsize=(8, 0.45 * len(wide) + 1.6))
    im = ax.imshow(wide.values, cmap="Blues", vmin=0, vmax=10, aspect="auto")
    for r in range(wide.shape[0]):
        for c in range(wide.shape[1]):
            v = wide.iat[r, c]
            ax.text(c, r, v, ha="center", va="center",
                    color="white" if v >= 7 else "black",
                    fontweight="bold" if liked.iat[r, c] else "normal")
            if liked.iat[r, c]:
                ax.add_patch(Rectangle((c - 0.5, r - 0.5), 1, 1, fill=False, lw=2.2, ec="#e8a33d"))
    ax.axvline(2.5, color="white", lw=3)
    ax.set_xticks(range(len(ALL_CUES)), ALL_CUES, rotation=20)
    ax.set_yticks(range(len(wide)), wide.index)
    ax.set_title("Usefulness scores per participant (orange box = most-liked cue)")
    for s in ax.spines.values():
        s.set_visible(False)
    fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02, label="Score")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "02_score_heatmap.png"))
    plt.close(fig)


def fig_intensity(summ, n, out):
    fig, ax = plt.subplots(figsize=(7, 3.8))
    colors = {"Decrease": COL_NEG, "Keep": COL_MUTED, "Increase": COL_POS}
    left = np.zeros(len(ALL_CUES))
    y = np.arange(len(ALL_CUES))[::-1]
    for k in INTENSITY_ORDER:
        vals = summ[k].to_numpy()
        ax.barh(y, vals, left=left, color=colors[k], label=k, edgecolor="white")
        for yi, l, v in zip(y, left, vals):
            if v:
                ax.text(l + v / 2, yi, int(v), ha="center", va="center", fontsize=9)
        left += vals
    ax.set_yticks(y, ALL_CUES)
    ax.set_xlim(0, n)
    ax.set_xlabel("Participants")
    ax.set_title("Requested guidance intensity per cue")
    ax.legend(ncol=3, loc="lower center", bbox_to_anchor=(0.5, -0.38), frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "03_intensity_requests.png"))
    plt.close(fig)


def fig_overview(parts, summ, out):
    """Spatial mapping, perception difference and most-liked counts."""
    n = len(parts)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    # (a) tested vs preferred mapping
    ax = axes[0]
    order = ["correct_back", "correct_front"]
    ct = pd.crosstab(parts["tested_mapping"], parts["preferred_mapping"]).reindex(
        index=order, columns=order, fill_value=0)
    ax.imshow(ct.values, cmap="Purples", vmin=0, vmax=n)
    for r in range(2):
        for c in range(2):
            ax.text(c, r, ct.iat[r, c], ha="center", va="center", fontsize=16,
                    color="white" if ct.iat[r, c] > n / 2 else "black")
    ax.set_xticks([0, 1], ["back", "front"])
    ax.set_yticks([0, 1], ["back", "front"])
    ax.set_xlabel("Preferred mapping")
    ax.set_ylabel("Tested with")
    same = (parts["tested_mapping"] == parts["preferred_mapping"]).sum()
    ax.set_title(f"Spatial mapping ({same}/{n} prefer the one tested)")
    for s in ax.spines.values():
        s.set_visible(False)

    # (b) perception difference
    ax = axes[1]
    cats = ["significantly_better", "almost_same"]
    cols = {"significantly_better": COL_POS, "almost_same": COL_MUTED}
    blocks = ["correct", "incorrect"]
    left = np.zeros(2)
    for cat in cats:
        vals = np.array([(parts[f"perception_{b}"] == cat).sum() for b in blocks])
        ax.barh(blocks, vals, left=left, color=cols[cat], label=cat.replace("_", " "), edgecolor="white")
        for i, (l, v) in enumerate(zip(left, vals)):
            if v:
                ax.text(l + v / 2, i, v, ha="center", va="center")
        left += vals
    ax.set_xlim(0, n)
    ax.invert_yaxis()
    ax.set_xlabel("Participants")
    ax.set_title("Perceived difference vs. no guidance")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.4), ncol=2, frameon=False)

    # (c) most-liked counts
    ax = axes[2]
    vals = summ["times_most_liked"].to_numpy()
    ax.bar(ALL_CUES, vals, color=[cue_color(c) for c in ALL_CUES])
    for i, v in enumerate(vals):
        ax.text(i, v + 0.1, int(v), ha="center")
    ax.set_ylim(0, n / 2 + 1)
    ax.set_ylabel("Participants")
    ax.set_title("Chosen as most-liked cue")
    ax.tick_params(axis="x", rotation=30)

    fig.tight_layout()
    fig.savefig(os.path.join(out, "04_mapping_perception_liked.png"))
    plt.close(fig)


def fig_participant_profile(cues, out):
    """Mean correct-cue vs incorrect-cue score per participant."""
    wide = cues.pivot(index="participant", columns="cue", values="score")
    pos, neg = wide[POS_CUES].mean(axis=1), wide[NEG_CUES].mean(axis=1)
    fig, ax = plt.subplots(figsize=(7, 3.8))
    for i, pid in enumerate(wide.index):
        ax.plot([0, 1], [pos[pid], neg[pid]], color="grey", lw=1, alpha=0.6)
        ax.text(1.04, neg[pid], pid, va="center", fontsize=8)
    ax.scatter(np.zeros(len(pos)), pos, color=COL_POS, s=45, zorder=3)
    ax.scatter(np.ones(len(neg)), neg, color=COL_NEG, s=45, zorder=3)
    ax.set_xticks([0, 1], ["Correct-action cues", "Incorrect-action cues"])
    ax.set_xlim(-0.3, 1.3)
    ax.set_ylim(0, 10.5)
    ax.set_ylabel("Mean usefulness (0–10)")
    ax.set_title("Per-participant mean usefulness, correct vs incorrect cues")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "05_participant_paired.png"))
    plt.close(fig)


# --------------------------------------------------------------------------- #
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", nargs="?", default=".", help="folder with pre_study_*.json")
    ap.add_argument("-o", "--out", default="pre_study_results", help="output folder")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    cues, parts = load(args.folder)
    n = parts["participant"].nunique()

    summ = cue_summary(cues)
    lv = liked_vs_top(cues)

    # ---- console report ----
    pd.set_option("display.width", 140)
    print(f"\n=== {n} participants ===\n")
    print("Per-cue summary (usefulness 0–10, intensity counts):")
    print(summ.to_string(), "\n")

    print("Guidance length:", parts["length_pref"].value_counts().to_dict())
    print("Preferred mapping:", parts["preferred_mapping"].value_counts().to_dict())
    print("Preferred = tested mapping:",
          int((parts["tested_mapping"] == parts["preferred_mapping"]).sum()), f"/ {n}")
    for b in BLOCKS:
        print(f"Perception ({b} cues):", parts[f"perception_{b}"].value_counts().to_dict())

    bad = lv[~lv["consistent"]]
    print(f"\nMost-liked cue is NOT the top-scored cue in {len(bad)} of {len(lv)} cases:")
    for _, r in bad.iterrows():
        print(f"  {r.participant} ({r.block}): liked {r.liked_cue} ({r.liked_score}) "
              f"but scored {r.top_cues} higher ({r.top_score})")

    print("\nTests (n is small - treat as exploratory):")
    for line in run_tests(cues):
        print("  " + line)

    # ---- files ----
    cues.to_csv(os.path.join(args.out, "cue_scores_long.csv"), index=False)
    parts.to_csv(os.path.join(args.out, "participants.csv"), index=False)
    summ.to_csv(os.path.join(args.out, "cue_summary.csv"))
    lv.to_csv(os.path.join(args.out, "liked_vs_top_score.csv"), index=False)

    fig_usefulness(cues, summ, args.out)
    fig_heatmap(cues, args.out)
    fig_intensity(summ, n, args.out)
    fig_overview(parts, summ, args.out)
    fig_participant_profile(cues, args.out)

    print(f"\nFigures and CSVs saved to: {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
